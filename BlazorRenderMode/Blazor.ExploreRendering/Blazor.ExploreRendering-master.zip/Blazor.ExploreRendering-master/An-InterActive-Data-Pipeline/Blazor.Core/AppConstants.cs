﻿namespace Blazor.Core;

public static class AppConstants
{
    public const string WeatherHttpClient = "WeatherHttpClient";
    public const string WeatherForecastListAPIUrl = "/API/Weather/GetForecasts";
    
}
