﻿global using Blazor.Core.CQS;
