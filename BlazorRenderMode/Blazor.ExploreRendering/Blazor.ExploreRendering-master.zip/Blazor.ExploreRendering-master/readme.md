# Exploring Render Modes

This repository is my knowledge store on the new Blazor Render Modes.  It's organized as a collection of notes and projects.  You need to change the StsrtUp project to run the different setups. 

This is Blazor, but not as we pre Net8 developers knew it.

Everything is either unfinished or unpolished and contains some personal views on some of the wrinkles I've found.

Articles so Far:

1. [Going For Broke](./Documents/Going-For-Broke.md) - Everyone's favourite seems to be the biggest minefield of all *AutoInteractive* and *Per Page/Component*.

2. [An Interactive Data Pipeline](./Documents/An-Interactive-Data-Pipeline.md) - demonstrates how to build a data pipleine that can be used in both Server and Client Side Contexts.

3. [Where Do I Put Componnets](./Documents/Where-Do-I-Put-Components.md) - under construction