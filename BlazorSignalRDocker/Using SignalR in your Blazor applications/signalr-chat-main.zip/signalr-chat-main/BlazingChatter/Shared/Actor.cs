﻿namespace BlazingChatter.Shared;

public record Actor(string User);
