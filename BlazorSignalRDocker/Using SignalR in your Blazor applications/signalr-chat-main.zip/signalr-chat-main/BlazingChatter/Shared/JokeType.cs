﻿namespace BlazingChatter.Enums;

public enum JokeType
{
    Dad,
    ChuckNorris
};