﻿namespace BlazingChatter.Enums;

public enum BotCommand
{
    None,
    TellJoke,
    SayJokes
};