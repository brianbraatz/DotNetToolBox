# Blazor Server With Docker
Companion code sample for my blog post - Containerising a Blazor Server App

Read the full blog post at [https://chrissainty.com/containerising-blazor-applications-with-docker-containerising-a-blazor-server-app/](https://chrissainty.com/containerising-blazor-applications-with-docker-containerising-a-blazor-server-app/).
