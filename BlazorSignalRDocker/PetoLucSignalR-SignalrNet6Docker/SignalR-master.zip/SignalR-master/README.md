# SignalR ASP.NET6 Razor pages app deployed as docker container to Azure kubernetes services 
[![Build Status](https://dev.azure.com/petolu/SignalRToAKS/_apis/build/status/PetoLuc.SignalR?branchName=master)](https://dev.azure.com/petolu/SignalRToAKS/_build/latest?definitionId=24&branchName=master)
