﻿https://docs.microsoft.com/en-us/dotnet/architecture/containerized-lifecycle/design-develop-containerized-apps/build-aspnet-core-applications-linux-containers-aks-kubernetes
kubernetes ui token:
https://github.com/kubernetes/dashboard/blob/v2.0.0/docs/user/access-control/README.md#authorization-header

AZureDevOps.pdf  page 385+
https://docs.microsoft.com/en-us/learn/modules/intro-to-kubernetes/1-introduction
https://vsupalov.com/docker-latest-tag/

docker app workflow:
https://docs.microsoft.com/en-us/dotnet/architecture/microservices/docker-application-development-process/docker-app-development-workflow