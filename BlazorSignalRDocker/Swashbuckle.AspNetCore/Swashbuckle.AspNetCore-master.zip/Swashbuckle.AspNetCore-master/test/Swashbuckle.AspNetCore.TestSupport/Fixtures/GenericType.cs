﻿namespace Swashbuckle.AspNetCore.TestSupport
{
    public class GenericType<T,K>
    {
        public T Property1 { get; set; }

        public K Property2 { get; set; }
    }
}
