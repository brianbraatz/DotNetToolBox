﻿using System.Collections.Generic;

namespace Swashbuckle.AspNetCore.TestSupport
{
    public class ListOfSelf : List<ListOfSelf>
    {
    }
}