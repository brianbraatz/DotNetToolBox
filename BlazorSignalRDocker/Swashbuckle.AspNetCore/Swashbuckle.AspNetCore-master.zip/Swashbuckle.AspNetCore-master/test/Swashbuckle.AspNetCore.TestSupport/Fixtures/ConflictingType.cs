﻿namespace Swashbuckle.AspNetCore.TestSupport
{
    namespace Namespace1
    {
        public class ConflictingType
        { }
    }

    namespace Namespace2
    {
        public class ConflictingType
        { }
    }
}