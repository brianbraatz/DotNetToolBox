﻿namespace Swashbuckle.AspNetCore.SwaggerGen
{
    public interface IDictionary<T>
    {
    }
}