# Blazor WebAssembly With Docker
Companion code sample for my blog post - Containerising a Blazor WebAssembly App

Read the full blog post at [https://chrissainty.com/containerising-blazor-applications-with-docker-containerising-a-blazor-webassembly-app/](https://chrissainty.com/containerising-blazor-applications-with-docker-containerising-a-blazor-webassembly-app/).


adding signalr 

https://learn.microsoft.com/en-us/aspnet/core/blazor/tutorials/signalr-blazor?view=aspnetcore-8.0&tabs=visual-studio

