# Blazor WebAssembly With Docker
Companion code sample for my blog post - Containerising a Blazor WebAssembly App

Read the full blog post at [https://chrissainty.com/containerising-blazor-applications-with-docker-containerising-a-blazor-webassembly-app/](https://chrissainty.com/containerising-blazor-applications-with-docker-containerising-a-blazor-webassembly-app/).
