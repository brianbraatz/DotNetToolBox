---
Compiles: false
Runs: false
Docker: false
SignalR: false
DotNetVersion: 
description: 
tags:
  - SampleCode
---


# BlazorSignalRApp

%% Begin Waypoint %%
- **bin**
	- **Debug**
		- **net8.0**
- **Components**
	- **Layout**

	- **Pages**

- **Hubs**

- **obj**
	- **Debug**
		- **net8.0**
			- **ref**
			- **refint**
			- **scopedcss**
				- **bundle**
				- **Components**
					- **Layout**
				- **projectbundle**
			- **staticwebassets**
- **Properties**

- **wwwroot**
	- **bootstrap**


%% End Waypoint %%
 