﻿namespace Blazor20Questions.Shared
{
    public class AnswerModel
    {
        public bool Answer { get; set; }
    }
}
