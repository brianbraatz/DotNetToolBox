﻿namespace Blazor20Questions.Shared
{
    public class GuessModel
    {
        public string Guess { get; set; }
    }
}
