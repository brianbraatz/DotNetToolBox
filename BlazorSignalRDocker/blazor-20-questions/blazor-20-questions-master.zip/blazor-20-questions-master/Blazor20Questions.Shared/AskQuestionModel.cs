﻿namespace Blazor20Questions.Shared
{
    public class AskQuestionModel
    {
        public string Question { get; set; }
    }
}
