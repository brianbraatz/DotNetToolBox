﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace signalr_scale_out
{
    public static class Info
    {
        public static string containerId="0";
    }
}
