﻿namespace Bar.CQRS.Commands.Tab
{
    public class OpenTab : TabCommand
    {
        public string ClientName { get; set; }
    }
}
