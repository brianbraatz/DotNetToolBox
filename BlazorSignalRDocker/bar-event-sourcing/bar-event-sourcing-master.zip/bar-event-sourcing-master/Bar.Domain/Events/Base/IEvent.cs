﻿using MediatR;

namespace Bar.Domain.Events.Base
{
    public interface IEvent : INotification
    {
    }
}
