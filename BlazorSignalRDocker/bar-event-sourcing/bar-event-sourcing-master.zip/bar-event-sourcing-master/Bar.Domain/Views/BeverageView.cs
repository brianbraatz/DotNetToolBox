﻿namespace Bar.Domain.Views
{
    public class BeverageView
    {
        public string Description { get; set; }
        public int MenuNumber { get; set; }
        public decimal Price { get; set; }
    }
}