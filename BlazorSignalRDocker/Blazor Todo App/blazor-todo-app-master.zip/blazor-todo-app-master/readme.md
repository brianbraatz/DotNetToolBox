# Blazor Sample Todo App with SignalR

This sample applicaiton shows Blazor WebAssembly with SignalR. Enjoy.

## Prerequisites

- [Visual Studio 2019 16.6](https://visualstudio.microsoft.com/downloads/?utm_medium=microsoft&utm_source=docs.microsoft.com&utm_campaign=inline+link&utm_content=download+vs2019) or later with the ASP.NET and web development workload
- [.NET Core 3.1 SDK](https://dotnet.microsoft.com/download/dotnet-core/3.1) or later

## Usage

Open the solution in VS and hit the "play" Button.

## Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## License

[MIT](https://choosealicense.com/licenses/mit/)
