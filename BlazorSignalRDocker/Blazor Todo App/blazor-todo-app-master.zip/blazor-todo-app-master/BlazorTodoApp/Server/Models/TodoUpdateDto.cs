﻿
namespace BlazorTodoApp.Server.Models
{
    public class TodoUpdateDto
    {
        public bool Done { get; set; }
    }
}
