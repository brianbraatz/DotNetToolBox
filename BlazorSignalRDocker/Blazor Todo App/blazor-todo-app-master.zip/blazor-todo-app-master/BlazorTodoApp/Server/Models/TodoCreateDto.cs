﻿
namespace BlazorTodoApp.Server.Models
{
    public class TodoCreateDto
    {
        public string Value { get; set; }
    }
}
