using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;

namespace BlazorTodoApp.Server.Hubs
{
    public class TodoHub : Hub
    {
    }
}