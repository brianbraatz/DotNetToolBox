namespace Microsoft.Net.Http.Client
{
    public enum ProxyMode
    {
        None,
        Http,
        Tunnel
    }
}