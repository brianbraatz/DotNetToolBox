# .NET Client for Docker Remote API

Fork from [Microsoft/Docker.DotNet](https://github.com/Microsoft/Docker.DotNet)
