﻿namespace Docker.DotNet
{
    internal interface IQueryString
    {
        string GetQueryString();
    }
}