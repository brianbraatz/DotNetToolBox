﻿
namespace Docker.DotNet.Models
{
    public enum FileSystemChangeKind
    {
        Modify = 0,
        Add,
        Delete
    }
}
