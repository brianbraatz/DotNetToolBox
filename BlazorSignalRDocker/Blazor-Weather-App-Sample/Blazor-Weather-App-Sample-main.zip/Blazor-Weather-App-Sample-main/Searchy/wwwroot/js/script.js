function submit(form) {
    form.submit();
}