using System.Collections.Generic;

namespace HubSample.Models
{
    public static class Items
    {
        public static List<string> List { get; } = new() {"Bacon", "Hammer", "Potato"};
    }
}