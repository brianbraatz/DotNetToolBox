using Microsoft.AspNetCore.SignalR;

namespace HubSample.Hubs
{
    public class ItemsHub : Hub
    {
        
    }
}