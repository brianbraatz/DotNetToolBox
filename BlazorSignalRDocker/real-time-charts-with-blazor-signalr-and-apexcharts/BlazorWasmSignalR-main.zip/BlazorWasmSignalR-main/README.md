# Real-time charts with Blazor, SignalR and ApexCharts

[Blog post](https://blog.genezini.com/p/real-time-charts-with-blazor-signalr-and-apexcharts/)