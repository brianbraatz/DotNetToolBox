namespace BlazorWasmSignalR.Wasm.Shared;

public record DataItem(string Minute, decimal Value);