
this is the version before adding docker
