# LearnBlazor.Server
Source code for my article Let's Learn Blazor: Building your first Server-Side Blazor App  

https://medium.com/it-dead-inside/lets-learn-blazor-blazor-server-with-signalr-457bec513d99

This is part of my ongoing series Let's Learn Blazor to help engineers get to know the ins and outs of Blazor.


