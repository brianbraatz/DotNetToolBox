# blazor-series - Blazor WebAssembly HttpClient - Consuming Web API 
## https://code-maze.com/blazor-webassembly-httpclient
This repository contains the source code for the "Blazor WebAssembly Series" on Code Maze blog
