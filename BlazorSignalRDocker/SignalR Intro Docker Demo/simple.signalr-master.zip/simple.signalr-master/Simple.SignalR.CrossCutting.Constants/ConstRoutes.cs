﻿namespace Simple.SignalR.CrossCutting.Constants
{
    public class ConstRoutes
    {
        public static string WS => "/ws";
    }
}
