﻿global using BlazingChat.Shared.DTOs;
