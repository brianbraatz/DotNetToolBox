﻿namespace BlazingChat.Shared.DTOs
{
    public record AuthResponseDto(UserDto User, string Token);
}
