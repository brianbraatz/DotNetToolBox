﻿namespace BlazingChat.Shared.DTOs
{
    public record MessageSendDto(int ToUserId, string Message);
}
