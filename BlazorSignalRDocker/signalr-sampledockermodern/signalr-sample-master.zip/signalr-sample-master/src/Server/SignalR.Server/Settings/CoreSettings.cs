﻿namespace SignalR.Server.Settings;

public class CoreSettings
{
    public string ServerUrl { get; set; }
}