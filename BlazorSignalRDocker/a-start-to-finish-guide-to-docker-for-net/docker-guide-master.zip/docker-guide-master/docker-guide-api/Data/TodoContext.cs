﻿using docker_guide_api.Entities;
using Microsoft.EntityFrameworkCore;

namespace docker_guide_api.Data
{
    public class TodoContext : DbContext
    {
        public TodoContext(DbContextOptions<TodoContext> options)
            : base(options)
        {
        }

        public DbSet<Todo> Todos { get; set; }
    }
}