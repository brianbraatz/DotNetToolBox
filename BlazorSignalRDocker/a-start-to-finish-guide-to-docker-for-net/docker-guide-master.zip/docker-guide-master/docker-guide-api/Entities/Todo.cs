﻿namespace docker_guide_api.Entities
{
    public class Todo
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}