#!/bin/sh

sudo docker build -t docker-guide/api docker-guide-api
sudo docker build -t docker-guide/ui docker-guide-ui
