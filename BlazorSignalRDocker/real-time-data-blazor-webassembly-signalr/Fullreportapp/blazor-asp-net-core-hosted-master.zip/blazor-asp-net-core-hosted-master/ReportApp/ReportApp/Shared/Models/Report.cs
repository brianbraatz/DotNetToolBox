namespace ReportApp.Shared.Models;

public class Report
{
    public DateTime Date { get; set; }

    public int DataCount { get; set; }
}
