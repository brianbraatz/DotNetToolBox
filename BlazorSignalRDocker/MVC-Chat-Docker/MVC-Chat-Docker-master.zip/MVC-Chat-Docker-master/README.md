# SignalRMVCChat

### 0.0.1 - Initial commit

### 0.0.2 - Created ChatHub.cs class

### 0.0.3 - Initial js and page structure

### 0.0.4 - Created Dockerfile