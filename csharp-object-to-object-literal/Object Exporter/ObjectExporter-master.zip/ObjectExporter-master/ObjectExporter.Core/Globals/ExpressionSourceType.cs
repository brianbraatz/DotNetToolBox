﻿namespace ObjectExporter.Core.Globals
{
    public enum ExpressionSourceType
    {
        Locals,
        CustomExpression
    }
}