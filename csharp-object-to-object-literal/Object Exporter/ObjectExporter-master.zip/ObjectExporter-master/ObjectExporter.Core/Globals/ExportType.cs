﻿namespace ObjectExporter.Core.Globals
{
    public enum ExportType
    {
        Json,
        Xml,
        CSharpObject
    }
}