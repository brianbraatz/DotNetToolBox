﻿namespace ObjectExporter.Core
{
    public static class ApiKeys
    {
        public const string RayGun = "{YOUR KEY HERE}";
    }
}
