﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ObjectExporter.Test
{
    [TestClass]
    public class TemplateTests
    {
        [TestMethod]
        public void CSharpExporter_EmptyTemplate()
        {
        }
    }
}
