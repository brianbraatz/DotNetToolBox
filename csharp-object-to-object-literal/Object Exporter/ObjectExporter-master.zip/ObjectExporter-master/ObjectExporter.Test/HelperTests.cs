﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ObjectExporter.VsPackage.Helpers;

namespace ObjectExporter.Test
{
    [TestClass]
    public class MyTestClass
    {
        [TestMethod]
        public void TestGetVersionNumber()
        {
            //string version = VsixManifestHelper.GetVersionNumber();
        }
    }
}
