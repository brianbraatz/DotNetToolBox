﻿// PkgCmdID.cs
// MUST match PkgCmdID.h

namespace ObjectExporter.VsPackage
{
    static class PkgCmdIDList
    {
        public const uint cmdidExportObjects = 0x100;
    };
}