﻿using System.Drawing;
using System.Windows.Forms;

namespace ObjectExporter.VsPackage.Views
{
    public static class UiExtensions
    {
        public static void AppendText(this RichTextBox box, string text, Color color)
        {
            box.SelectionStart = box.TextLength;
            box.SelectionLength = 0;

            box.SelectionColor = color;
            box.AppendText(text);
            box.SelectionColor = box.ForeColor;
        }
    }
}
